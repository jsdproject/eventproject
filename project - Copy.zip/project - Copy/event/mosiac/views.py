from django.shortcuts import render

# Create your views here.
def page(request):
    return render(request, 'demo.html')

def second(request):
    return render(request, 'Catering.html')