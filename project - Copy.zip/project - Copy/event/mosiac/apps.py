from django.apps import AppConfig


class MosiacConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mosiac'
